module example.com/mcp533-capacity-evidence

go 1.25.0

require github.com/modelcontextprotocol/go-sdk v0.0.0

replace github.com/modelcontextprotocol/go-sdk => "/home/runner/work/conformance/conformance/go-sdk"
